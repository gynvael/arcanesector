The game was tested on Ubuntu 18.04.1 LTS.
It requires SDL2 and SDL2 Image to run locally, or can use websocket for a thin client.
